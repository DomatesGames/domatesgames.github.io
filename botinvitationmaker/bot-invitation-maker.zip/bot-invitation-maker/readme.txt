This is Bot Invitation Maker's compiled version. (Compiled with PyInstaller)

Tomato Timer's compiled version. (Compiled with PyInstaller.)

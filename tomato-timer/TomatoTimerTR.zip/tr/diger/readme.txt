Bu Tomato Timer'ın derlenmiş halidir. (PyInstaller ile derlendi.)
